package scripts;

public enum States {
  
  
 COOKING_FISH, PICKING_FISH

}
